'use client'

import { Navbar } from '@/components/navbar'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { CheckCircle, AlertCircle, Clock, Zap } from 'lucide-react'
import { useState } from 'react'

const testCategories = [
  {
    name: 'Alpha Testing',
    id: 'alpha',
    status: 'active',
    color: 'bg-blue-500/10 border-blue-500/30 text-blue-400',
    icon: Zap,
    testCases: 45,
    coverage: 72,
    description: 'Initial testing phase with core features and basic functionality',
  },
  {
    name: 'Beta Testing',
    id: 'beta',
    status: 'active',
    color: 'bg-purple-500/10 border-purple-500/30 text-purple-400',
    icon: CheckCircle,
    testCases: 68,
    coverage: 85,
    description: 'Extended testing with real-world scenarios and edge cases',
  },
  {
    name: 'Unit Testing',
    id: 'unit',
    status: 'complete',
    color: 'bg-green-500/10 border-green-500/30 text-green-400',
    icon: CheckCircle,
    testCases: 156,
    coverage: 95,
    description: 'Individual component and function testing',
  },
  {
    name: 'Integration Testing',
    id: 'integration',
    status: 'active',
    color: 'bg-amber-500/10 border-amber-500/30 text-amber-400',
    icon: AlertCircle,
    testCases: 92,
    coverage: 88,
    description: 'Testing interactions between different modules',
  },
  {
    name: 'UAT',
    id: 'uat',
    status: 'pending',
    color: 'bg-gray-500/10 border-gray-500/30 text-gray-400',
    icon: Clock,
    testCases: 34,
    coverage: 0,
    description: 'User acceptance testing with stakeholders',
  },
  {
    name: 'Responsive Testing',
    id: 'responsive',
    status: 'active',
    color: 'bg-cyan-500/10 border-cyan-500/30 text-cyan-400',
    icon: CheckCircle,
    testCases: 28,
    coverage: 92,
    description: 'Testing across different screen sizes and devices',
  },
]

const testCases = {
  alpha: [
    {
      id: 'TC-001',
      name: 'User Registration Flow',
      status: 'passed',
      description: 'Test complete member registration process',
      steps: 5,
    },
    {
      id: 'TC-002',
      name: 'Login Authentication',
      status: 'passed',
      description: 'Verify login with valid and invalid credentials',
      steps: 4,
    },
    {
      id: 'TC-003',
      name: 'Dashboard Access',
      status: 'passed',
      description: 'Verify dashboard displays correctly by role',
      steps: 3,
    },
    {
      id: 'TC-004',
      name: 'Profile Update',
      status: 'failed',
      description: 'Test member profile updates',
      steps: 6,
    },
  ],
  beta: [
    {
      id: 'TC-005',
      name: 'Payment Processing',
      status: 'passed',
      description: 'Test PayMongo integration',
      steps: 8,
    },
    {
      id: 'TC-006',
      name: 'Subscription Renewal',
      status: 'passed',
      description: 'Test automatic subscription renewal',
      steps: 7,
    },
    {
      id: 'TC-007',
      name: 'QR Code Generation',
      status: 'in-progress',
      description: 'Test QR code creation and scanning',
      steps: 5,
    },
  ],
  unit: [
    {
      id: 'TC-008',
      name: 'Authentication Module',
      status: 'passed',
      description: 'Unit tests for auth functions',
      steps: 12,
    },
    {
      id: 'TC-009',
      name: 'Data Validation',
      status: 'passed',
      description: 'Test input validation functions',
      steps: 15,
    },
  ],
}

export default function QAPage() {
  const [selectedCategory, setSelectedCategory] = useState('alpha')

  return (
    <>
      <Navbar />
      
      <div className="min-h-screen bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          {/* Header */}
          <div className="text-center mb-16">
            <h1 className="text-4xl sm:text-5xl font-bold mb-4">QA Testing Documentation</h1>
            <p className="text-lg text-muted-foreground">Comprehensive testing coverage and validation results</p>
          </div>

          {/* Test Categories Overview */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-12">
            {testCategories.map((category) => {
              const Icon = category.icon
              return (
                <button
                  key={category.id}
                  onClick={() => setSelectedCategory(category.id)}
                  className={`p-6 rounded-lg border transition-all text-left ${
                    selectedCategory === category.id
                      ? `border-accent/50 bg-accent/10`
                      : `border-border/50 hover:border-accent/30 hover:bg-card/50`
                  }`}
                >
                  <div className={`w-10 h-10 rounded-lg border ${category.color} flex items-center justify-center mb-4`}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <h3 className="font-semibold mb-2">{category.name}</h3>
                  <div className="space-y-1 text-sm text-muted-foreground">
                    <p>{category.testCases} test cases</p>
                    <div className="flex items-center gap-2 pt-2">
                      <div className="flex-1 h-2 bg-background rounded-full overflow-hidden">
                        <div
                          className="h-full bg-accent rounded-full transition-all"
                          style={{ width: `${category.coverage}%` }}
                        />
                      </div>
                      <span className="text-xs">{category.coverage}%</span>
                    </div>
                  </div>
                </button>
              )
            })}
          </div>

          {/* Detailed Test Results */}
          <div className="bg-card/30 border border-border/50 rounded-lg p-8 mb-12">
            <div className="mb-8">
              <h2 className="text-2xl font-bold mb-2">
                {testCategories.find(c => c.id === selectedCategory)?.name}
              </h2>
              <p className="text-muted-foreground">
                {testCategories.find(c => c.id === selectedCategory)?.description}
              </p>
            </div>

            <Tabs defaultValue="cases" className="space-y-6">
              <TabsList className="grid w-full grid-cols-3 bg-card/50 border border-border/50">
                <TabsTrigger value="cases">Test Cases</TabsTrigger>
                <TabsTrigger value="results">Results</TabsTrigger>
                <TabsTrigger value="summary">Summary</TabsTrigger>
              </TabsList>

              <TabsContent value="cases" className="space-y-4">
                {testCases[selectedCategory as keyof typeof testCases]?.map((testCase) => (
                  <div key={testCase.id} className="p-4 border border-border/50 rounded-lg hover:bg-card/50 transition-colors">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <h3 className="font-semibold">{testCase.name}</h3>
                        <p className="text-sm text-muted-foreground mt-1">{testCase.description}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-mono text-muted-foreground">{testCase.id}</span>
                        <span
                          className={`px-3 py-1 rounded-full text-xs font-semibold ${
                            testCase.status === 'passed'
                              ? 'bg-green-500/20 text-green-400'
                              : testCase.status === 'failed'
                              ? 'bg-red-500/20 text-red-400'
                              : 'bg-yellow-500/20 text-yellow-400'
                          }`}
                        >
                          {testCase.status}
                        </span>
                      </div>
                    </div>
                    <p className="text-xs text-muted-foreground">{testCase.steps} steps</p>
                  </div>
                )) || (
                  <div className="text-center py-8">
                    <p className="text-muted-foreground">No test cases available</p>
                  </div>
                )}
              </TabsContent>

              <TabsContent value="results" className="space-y-4">
                <div className="grid grid-cols-3 gap-4 mb-6">
                  <div className="p-4 bg-green-500/10 border border-green-500/30 rounded-lg text-center">
                    <div className="text-2xl font-bold text-green-400 mb-1">
                      {testCases[selectedCategory as keyof typeof testCases]?.filter(t => t.status === 'passed').length || 0}
                    </div>
                    <p className="text-sm text-muted-foreground">Passed</p>
                  </div>
                  <div className="p-4 bg-red-500/10 border border-red-500/30 rounded-lg text-center">
                    <div className="text-2xl font-bold text-red-400 mb-1">
                      {testCases[selectedCategory as keyof typeof testCases]?.filter(t => t.status === 'failed').length || 0}
                    </div>
                    <p className="text-sm text-muted-foreground">Failed</p>
                  </div>
                  <div className="p-4 bg-yellow-500/10 border border-yellow-500/30 rounded-lg text-center">
                    <div className="text-2xl font-bold text-yellow-400 mb-1">
                      {testCases[selectedCategory as keyof typeof testCases]?.filter(t => t.status === 'in-progress').length || 0}
                    </div>
                    <p className="text-sm text-muted-foreground">In Progress</p>
                  </div>
                </div>

                <div className="p-6 bg-background/50 rounded-lg border border-border/50">
                  <h3 className="font-semibold mb-4">Test Execution Summary</h3>
                  <div className="space-y-3 text-sm text-muted-foreground">
                    <div className="flex justify-between items-center pb-3 border-b border-border/50">
                      <span>Total Tests:</span>
                      <span className="font-semibold text-foreground">
                        {testCases[selectedCategory as keyof typeof testCases]?.length || 0}
                      </span>
                    </div>
                    <div className="flex justify-between items-center pb-3 border-b border-border/50">
                      <span>Pass Rate:</span>
                      <span className="font-semibold text-green-400">
                        {testCases[selectedCategory as keyof typeof testCases]?.length
                          ? Math.round(
                              (testCases[selectedCategory as keyof typeof testCases]?.filter(t => t.status === 'passed').length /
                                testCases[selectedCategory as keyof typeof testCases]?.length) *
                              100
                            )
                          : 0}
                        %
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Last Updated:</span>
                      <span className="font-semibold text-foreground">Today</span>
                    </div>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="summary" className="space-y-4">
                <div className="p-6 bg-background/50 rounded-lg border border-border/50">
                  <h3 className="font-semibold mb-4">Test Category Summary</h3>
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between mb-2">
                        <span className="text-sm">Code Coverage</span>
                        <span className="text-sm font-semibold">
                          {testCategories.find(c => c.id === selectedCategory)?.coverage}%
                        </span>
                      </div>
                      <div className="h-2 bg-background rounded-full overflow-hidden">
                        <div
                          className="h-full bg-accent rounded-full"
                          style={{
                            width: `${testCategories.find(c => c.id === selectedCategory)?.coverage}%`,
                          }}
                        />
                      </div>
                    </div>
                    <div className="p-4 bg-card rounded-lg mt-4">
                      <p className="text-sm text-muted-foreground leading-relaxed">
                        This testing phase focuses on validating {testCategories.find(c => c.id === selectedCategory)?.name.toLowerCase()}{' '}
                        requirements. All critical paths have been verified and edge cases are being addressed systematically.
                      </p>
                    </div>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </div>

          {/* Testing Guidelines */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-card/30 border border-border/50 rounded-lg p-8">
              <h3 className="text-xl font-bold mb-4">Testing Standards</h3>
              <ul className="space-y-3 text-sm text-muted-foreground">
                <li className="flex gap-2">
                  <span className="text-accent">•</span>
                  <span>All test cases follow standardized format</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-accent">•</span>
                  <span>Minimum 80% code coverage required</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-accent">•</span>
                  <span>Cross-browser testing mandatory</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-accent">•</span>
                  <span>Performance benchmarks enforced</span>
                </li>
              </ul>
            </div>

            <div className="bg-card/30 border border-border/50 rounded-lg p-8">
              <h3 className="text-xl font-bold mb-4">Test Coverage Goals</h3>
              <ul className="space-y-3 text-sm text-muted-foreground">
                <li className="flex gap-2">
                  <span className="text-accent">•</span>
                  <span>Unit Tests: 95% coverage</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-accent">•</span>
                  <span>Integration Tests: 90% coverage</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-accent">•</span>
                  <span>E2E Tests: 85% coverage</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-accent">•</span>
                  <span>Overall: 90% target</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}
