'use client'

import { Navbar } from '@/components/navbar'
import { Card } from '@/components/ui/card'
import { Crown, Users, User, Lock, CheckCircle } from 'lucide-react'

const roles = [
  {
    name: 'Owner',
    level: 0,
    icon: Crown,
    color: 'bg-red-500/10 border-red-500/30 text-red-400',
    permissions: [
      'Full system access',
      'Create/manage staff and coaches',
      'Approve member registrations',
      'Manage payments and subscriptions',
      'View all reports and analytics',
      'System configuration',
      'Audit logs and compliance',
    ],
  },
  {
    name: 'Staff',
    level: 1,
    icon: Users,
    color: 'bg-amber-500/10 border-amber-500/30 text-amber-400',
    permissions: [
      'Manage member registrations',
      'View member profiles',
      'Process payments',
      'Manage schedules',
      'Generate reports',
      'View analytics',
    ],
  },
  {
    name: 'Coach',
    level: 1,
    icon: User,
    color: 'bg-blue-500/10 border-blue-500/30 text-blue-400',
    permissions: [
      'View assigned members',
      'Manage class schedules',
      'Track member attendance',
      'Create workout plans',
      'View basic analytics',
    ],
  },
  {
    name: 'Member',
    level: 2,
    icon: Lock,
    color: 'bg-green-500/10 border-green-500/30 text-green-400',
    permissions: [
      'View own profile',
      'Access personal dashboard',
      'Check in with QR',
      'View class schedules',
      'Book classes',
      'View personal analytics',
      'Manage subscriptions',
    ],
  },
]

export default function HierarchyPage() {
  return (
    <>
      <Navbar />
      
      <div className="min-h-screen bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          {/* Header */}
          <div className="text-center mb-16">
            <h1 className="text-4xl sm:text-5xl font-bold mb-4">Account Hierarchy & RBAC</h1>
            <p className="text-lg text-muted-foreground">Role-based access control matrix and permission inheritance</p>
          </div>

          {/* Hierarchy Diagram */}
          <div className="mb-16 p-8 bg-card/30 border border-border/50 rounded-lg">
            <h2 className="text-2xl font-bold mb-8 text-center">Organizational Hierarchy</h2>
            <div className="space-y-8">
              {/* Owner Level */}
              <div className="flex flex-col items-center">
                <div className="p-4 rounded-lg bg-red-500/10 border-2 border-red-500/30 text-center min-w-xs">
                  <Crown className="w-8 h-8 text-red-400 mx-auto mb-2" />
                  <p className="font-semibold">Owner</p>
                  <p className="text-xs text-muted-foreground">Full System Access</p>
                </div>
                <div className="w-1 h-8 bg-gradient-to-b from-red-500/50 to-transparent" />
              </div>

              {/* Staff & Coach Level */}
              <div className="flex justify-center gap-12">
                <div className="flex flex-col items-center flex-1 max-w-xs">
                  <div className="w-1 h-8 bg-gradient-to-b from-transparent to-amber-500/50" />
                  <div className="p-4 rounded-lg bg-amber-500/10 border-2 border-amber-500/30 text-center w-full">
                    <Users className="w-8 h-8 text-amber-400 mx-auto mb-2" />
                    <p className="font-semibold">Staff</p>
                    <p className="text-xs text-muted-foreground">Management Access</p>
                  </div>
                </div>
                <div className="flex flex-col items-center flex-1 max-w-xs">
                  <div className="w-1 h-8 bg-gradient-to-b from-transparent to-blue-500/50" />
                  <div className="p-4 rounded-lg bg-blue-500/10 border-2 border-blue-500/30 text-center w-full">
                    <User className="w-8 h-8 text-blue-400 mx-auto mb-2" />
                    <p className="font-semibold">Coach</p>
                    <p className="text-xs text-muted-foreground">Limited Access</p>
                  </div>
                </div>
              </div>

              {/* Member Level */}
              <div className="flex justify-center">
                <div className="w-96 flex flex-col items-center">
                  <div className="w-1 h-8 bg-gradient-to-b from-transparent to-green-500/50" />
                  <div className="p-4 rounded-lg bg-green-500/10 border-2 border-green-500/30 text-center w-full">
                    <Lock className="w-8 h-8 text-green-400 mx-auto mb-2" />
                    <p className="font-semibold">Members</p>
                    <p className="text-xs text-muted-foreground">User Access</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Permission Matrix */}
          <div className="mb-16">
            <h2 className="text-2xl font-bold mb-8">Permission Matrix</h2>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border/50">
                    <th className="text-left py-3 px-4 font-semibold">Feature</th>
                    <th className="text-center py-3 px-4 font-semibold">Owner</th>
                    <th className="text-center py-3 px-4 font-semibold">Staff</th>
                    <th className="text-center py-3 px-4 font-semibold">Coach</th>
                    <th className="text-center py-3 px-4 font-semibold">Member</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border/50">
                  {[
                    { feature: 'Member Management', owner: true, staff: true, coach: false, member: false },
                    { feature: 'Coach Management', owner: true, staff: true, coach: false, member: false },
                    { feature: 'Staff Management', owner: true, staff: false, coach: false, member: false },
                    { feature: 'Payment Processing', owner: true, staff: true, coach: false, member: false },
                    { feature: 'Schedule Management', owner: true, staff: true, coach: true, member: false },
                    { feature: 'QR Check-In', owner: true, staff: true, coach: true, member: true },
                    { feature: 'Class Booking', owner: true, staff: true, coach: true, member: true },
                    { feature: 'View Analytics', owner: true, staff: true, coach: true, member: true },
                    { feature: 'System Settings', owner: true, staff: false, coach: false, member: false },
                    { feature: 'Audit Logs', owner: true, staff: true, coach: false, member: false },
                  ].map((row) => (
                    <tr key={row.feature} className="hover:bg-card/30 transition-colors">
                      <td className="py-3 px-4 font-medium">{row.feature}</td>
                      <td className="py-3 px-4 text-center">
                        {row.owner && <CheckCircle className="w-5 h-5 text-green-400 mx-auto" />}
                      </td>
                      <td className="py-3 px-4 text-center">
                        {row.staff && <CheckCircle className="w-5 h-5 text-green-400 mx-auto" />}
                      </td>
                      <td className="py-3 px-4 text-center">
                        {row.coach && <CheckCircle className="w-5 h-5 text-green-400 mx-auto" />}
                      </td>
                      <td className="py-3 px-4 text-center">
                        {row.member && <CheckCircle className="w-5 h-5 text-green-400 mx-auto" />}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Detailed Role Information */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-16">
            {roles.map((role) => {
              const Icon = role.icon
              return (
                <Card key={role.name} className="border-border/50 bg-card/30 p-6">
                  <div className="flex items-start gap-4 mb-6">
                    <div className={`p-3 rounded-lg border ${role.color}`}>
                      <Icon className="w-6 h-6" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold">{role.name}</h3>
                      <p className="text-sm text-muted-foreground">
                        {role.level === 0 && 'Full system access with all permissions'}
                        {role.level === 1 && 'Specialized role with limited access'}
                        {role.level === 2 && 'User role with personal access only'}
                      </p>
                    </div>
                  </div>

                  <div>
                    <h4 className="font-semibold mb-3 text-sm">Key Permissions:</h4>
                    <ul className="space-y-2">
                      {role.permissions.map((permission) => (
                        <li key={permission} className="flex items-start gap-2 text-sm text-muted-foreground">
                          <span className="text-accent mt-1">•</span>
                          <span>{permission}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </Card>
              )
            })}
          </div>

          {/* Inheritance Rules */}
          <div className="bg-card/30 border border-border/50 rounded-lg p-8">
            <h2 className="text-2xl font-bold mb-6">Permission Inheritance Rules</h2>
            <div className="space-y-4">
              <div className="p-4 bg-background/50 rounded-lg border-l-4 border-accent">
                <h3 className="font-semibold mb-2">Hierarchy-Based Access</h3>
                <p className="text-muted-foreground text-sm">
                  Each level inherits access rights from lower levels but adds restrictions. Higher-level roles have more permissions than lower-level roles.
                </p>
              </div>
              <div className="p-4 bg-background/50 rounded-lg border-l-4 border-accent">
                <h3 className="font-semibold mb-2">Cascading Permissions</h3>
                <p className="text-muted-foreground text-sm">
                  When a staff member manages a sub-account, they gain access to the same operations within that account scope.
                </p>
              </div>
              <div className="p-4 bg-background/50 rounded-lg border-l-4 border-accent">
                <h3 className="font-semibold mb-2">Audit Trail</h3>
                <p className="text-muted-foreground text-sm">
                  All permission-based actions are logged with user, timestamp, and details for compliance and troubleshooting.
                </p>
              </div>
              <div className="p-4 bg-background/50 rounded-lg border-l-4 border-accent">
                <h3 className="font-semibold mb-2">Role Changes</h3>
                <p className="text-muted-foreground text-sm">
                  When a user role is changed, permissions update immediately. Previous actions remain logged for audit purposes.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}
