'use client'

import { Navbar } from '@/components/navbar'
import { Card } from '@/components/ui/card'
import { Database, Server, Globe, Lock, CreditCard, QrCode, BarChart3, Zap } from 'lucide-react'

const architectureComponents = [
  {
    name: 'Frontend',
    icon: Globe,
    color: 'bg-blue-500/10 border-blue-500/30 text-blue-400',
    tech: ['Next.js 16', 'React 19', 'TypeScript', 'Tailwind CSS', 'Framer Motion'],
    description: 'Modern responsive web interface with real-time updates and smooth animations',
    responsibilities: [
      'User interface and interactions',
      'State management with hooks',
      'Real-time notifications',
      'Responsive design',
    ],
  },
  {
    name: 'Backend API',
    icon: Server,
    color: 'bg-purple-500/10 border-purple-500/30 text-purple-400',
    tech: ['Node.js', 'Express.js', 'REST API', 'WebSockets', 'Middleware'],
    description: 'Robust backend services handling business logic and data operations',
    responsibilities: [
      'Business logic implementation',
      'API endpoints',
      'Request validation',
      'Error handling',
      'Rate limiting',
    ],
  },
  {
    name: 'Database',
    icon: Database,
    color: 'bg-green-500/10 border-green-500/30 text-green-400',
    tech: ['PostgreSQL', 'Neon', 'Migrations', 'Indexing', 'Backup'],
    description: 'Scalable relational database with comprehensive data management',
    responsibilities: [
      'Data storage',
      'Query optimization',
      'Data integrity',
      'Backup and recovery',
      'Performance tuning',
    ],
  },
  {
    name: 'Authentication',
    icon: Lock,
    color: 'bg-red-500/10 border-red-500/30 text-red-400',
    tech: ['Clerk', 'JWT', 'OAuth 2.0', 'Session Management', 'MFA'],
    description: 'Secure authentication system with role-based access control',
    responsibilities: [
      'User authentication',
      'Permission management',
      'Session handling',
      'Security policies',
      'Audit logging',
    ],
  },
  {
    name: 'Payment Processing',
    icon: CreditCard,
    color: 'bg-amber-500/10 border-amber-500/30 text-amber-400',
    tech: ['PayMongo', 'Webhooks', 'Transaction Logs', 'Reconciliation'],
    description: 'Integrated payment gateway for secure transactions',
    responsibilities: [
      'Payment processing',
      'Transaction management',
      'Webhook handling',
      'Receipt generation',
      'Refund management',
    ],
  },
  {
    name: 'QR System',
    icon: QrCode,
    color: 'bg-cyan-500/10 border-cyan-500/30 text-cyan-400',
    tech: ['QR Code Library', 'Barcode Scanner', 'Real-time Sync'],
    description: 'QR code generation and scanning for attendance tracking',
    responsibilities: [
      'QR code generation',
      'Attendance recording',
      'Check-in tracking',
      'Real-time updates',
    ],
  },
  {
    name: 'Analytics Engine',
    icon: BarChart3,
    color: 'bg-pink-500/10 border-pink-500/30 text-pink-400',
    tech: ['Machine Learning', 'Logistic Regression', 'Random Forest', 'Data Pipeline'],
    description: 'AI-powered analytics for member insights and predictions',
    responsibilities: [
      'Predictive modeling',
      'Data analysis',
      'Report generation',
      'Trend detection',
      'Member profiling',
    ],
  },
  {
    name: 'Infrastructure',
    icon: Zap,
    color: 'bg-yellow-500/10 border-yellow-500/30 text-yellow-400',
    tech: ['Vercel', 'Docker', 'CI/CD', 'Monitoring', 'Logging'],
    description: 'Deployment and infrastructure management',
    responsibilities: [
      'Application hosting',
      'Auto-scaling',
      'Monitoring',
      'Alerts',
      'Performance optimization',
    ],
  },
]

const systemFlow = [
  { step: '1', label: 'User Request', description: 'Frontend sends request to API' },
  { step: '2', label: 'Authentication', description: 'Clerk validates user credentials' },
  { step: '3', label: 'Authorization', description: 'System checks user permissions' },
  { step: '4', label: 'Processing', description: 'Backend processes the request' },
  { step: '5', label: 'Database', description: 'Query/update database as needed' },
  { step: '6', label: 'Response', description: 'API returns result to frontend' },
]

export default function ArchitecturePage() {
  return (
    <>
      <Navbar />
      
      <div className="min-h-screen bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          {/* Header */}
          <div className="text-center mb-16">
            <h1 className="text-4xl sm:text-5xl font-bold mb-4">System Architecture</h1>
            <p className="text-lg text-muted-foreground">Technical overview of GNEX 360 platform components</p>
          </div>

          {/* System Flow */}
          <div className="mb-16 bg-card/30 border border-border/50 rounded-lg p-8">
            <h2 className="text-2xl font-bold mb-8 text-center">Request Flow Diagram</h2>
            <div className="overflow-x-auto">
              <div className="flex items-center justify-between min-w-max gap-4">
                {systemFlow.map((flow, index) => (
                  <div key={index} className="flex items-center">
                    <div className="text-center">
                      <div className="w-16 h-16 rounded-lg bg-accent/10 border-2 border-accent/50 flex items-center justify-center font-semibold text-accent mb-2 mx-auto">
                        {flow.step}
                      </div>
                      <p className="text-xs font-semibold text-foreground max-w-[100px] mb-1">{flow.label}</p>
                      <p className="text-xs text-muted-foreground max-w-[100px]">{flow.description}</p>
                    </div>
                    {index < systemFlow.length - 1 && (
                      <div className="w-8 flex justify-center">
                        <div className="w-6 h-1 bg-accent/30 rounded" />
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Architecture Components */}
          <div className="mb-16">
            <h2 className="text-2xl font-bold mb-8">System Components</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {architectureComponents.map((component) => {
                const Icon = component.icon
                return (
                  <Card key={component.name} className="border-border/50 bg-card/30 p-6">
                    <div className="flex items-start gap-4 mb-4">
                      <div className={`p-3 rounded-lg border ${component.color}`}>
                        <Icon className="w-6 h-6" />
                      </div>
                      <div>
                        <h3 className="text-lg font-bold">{component.name}</h3>
                        <p className="text-sm text-muted-foreground mt-1">{component.description}</p>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <div>
                        <h4 className="text-sm font-semibold mb-2">Technologies:</h4>
                        <div className="flex flex-wrap gap-2">
                          {component.tech.map((tech) => (
                            <span
                              key={tech}
                              className="px-2.5 py-1 rounded text-xs bg-background/50 border border-border/50 text-muted-foreground"
                            >
                              {tech}
                            </span>
                          ))}
                        </div>
                      </div>

                      <div>
                        <h4 className="text-sm font-semibold mb-2">Responsibilities:</h4>
                        <ul className="space-y-1">
                          {component.responsibilities.map((resp) => (
                            <li key={resp} className="flex items-start gap-2 text-xs text-muted-foreground">
                              <span className="text-accent mt-0.5">•</span>
                              <span>{resp}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </Card>
                )
              })}
            </div>
          </div>

          {/* Integration Points */}
          <div className="mb-16">
            <h2 className="text-2xl font-bold mb-8">External Integrations</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="border-border/50 bg-card/30 p-6">
                <h3 className="text-lg font-bold mb-4">Payment Gateway</h3>
                <div className="space-y-3 text-sm">
                  <div>
                    <p className="font-semibold text-foreground mb-1">PayMongo</p>
                    <p className="text-muted-foreground">Handles all payment processing and transactions securely</p>
                  </div>
                  <div className="p-3 bg-background/50 rounded border border-border/50 font-mono text-xs text-muted-foreground">
                    POST /payments/create
                  </div>
                </div>
              </Card>

              <Card className="border-border/50 bg-card/30 p-6">
                <h3 className="text-lg font-bold mb-4">Authentication</h3>
                <div className="space-y-3 text-sm">
                  <div>
                    <p className="font-semibold text-foreground mb-1">Clerk</p>
                    <p className="text-muted-foreground">Manages user authentication and session management</p>
                  </div>
                  <div className="p-3 bg-background/50 rounded border border-border/50 font-mono text-xs text-muted-foreground">
                    POST /auth/verify
                  </div>
                </div>
              </Card>

              <Card className="border-border/50 bg-card/30 p-6">
                <h3 className="text-lg font-bold mb-4">Analytics</h3>
                <div className="space-y-3 text-sm">
                  <div>
                    <p className="font-semibold text-foreground mb-1">ML Pipeline</p>
                    <p className="text-muted-foreground">Processes data for predictive models and insights</p>
                  </div>
                  <div className="p-3 bg-background/50 rounded border border-border/50 font-mono text-xs text-muted-foreground">
                    POST /analytics/predict
                  </div>
                </div>
              </Card>

              <Card className="border-border/50 bg-card/30 p-6">
                <h3 className="text-lg font-bold mb-4">Storage</h3>
                <div className="space-y-3 text-sm">
                  <div>
                    <p className="font-semibold text-foreground mb-1">Vercel Blob</p>
                    <p className="text-muted-foreground">Handles file uploads and media storage</p>
                  </div>
                  <div className="p-3 bg-background/50 rounded border border-border/50 font-mono text-xs text-muted-foreground">
                    PUT /storage/upload
                  </div>
                </div>
              </Card>
            </div>
          </div>

          {/* Deployment Architecture */}
          <div className="bg-card/30 border border-border/50 rounded-lg p-8">
            <h2 className="text-2xl font-bold mb-8">Deployment Architecture</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="p-6 border border-border/50 rounded-lg bg-background/50">
                <h3 className="font-bold mb-3">Frontend</h3>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li>• Deployed on Vercel</li>
                  <li>• Global CDN</li>
                  <li>• Auto-scaling</li>
                  <li>• Zero-downtime deploys</li>
                </ul>
              </div>
              <div className="p-6 border border-border/50 rounded-lg bg-background/50">
                <h3 className="font-bold mb-3">Backend</h3>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li>• API Routes on Vercel</li>
                  <li>• Serverless functions</li>
                  <li>• Auto-scaling</li>
                  <li>• Request logging</li>
                </ul>
              </div>
              <div className="p-6 border border-border/50 rounded-lg bg-background/50">
                <h3 className="font-bold mb-3">Database</h3>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li>• Neon PostgreSQL</li>
                  <li>• Serverless</li>
                  <li>• Auto-backup</li>
                  <li>• High availability</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Security Architecture */}
          <div className="mt-16 bg-card/30 border border-border/50 rounded-lg p-8">
            <h2 className="text-2xl font-bold mb-8">Security Measures</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <h3 className="font-bold mb-4">Authentication & Authorization</h3>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li className="flex gap-2">
                    <span className="text-accent">•</span>
                    <span>Multi-factor authentication support</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-accent">•</span>
                    <span>Role-based access control (RBAC)</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-accent">•</span>
                    <span>JWT token management</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-accent">•</span>
                    <span>Session timeout policies</span>
                  </li>
                </ul>
              </div>
              <div className="space-y-4">
                <h3 className="font-bold mb-4">Data Protection</h3>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li className="flex gap-2">
                    <span className="text-accent">•</span>
                    <span>HTTPS/TLS encryption</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-accent">•</span>
                    <span>Database encryption at rest</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-accent">•</span>
                    <span>Regular security audits</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-accent">•</span>
                    <span>Compliance with data protection laws</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}
