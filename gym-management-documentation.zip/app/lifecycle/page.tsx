'use client'

import { Navbar } from '@/components/navbar'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { CheckCircle, Clock, AlertCircle, ArrowRight } from 'lucide-react'
import { useState } from 'react'

const workflows = [
  {
    title: 'Member Onboarding Lifecycle',
    id: 'member-onboarding',
    steps: [
      { title: 'Registration', description: 'Member clicks "Join Now" and fills registration form', icon: '1' },
      { title: 'Plan Selection', description: 'Choose annual membership fee and preferred plan', icon: '2' },
      { title: 'Payment', description: 'Select payment method (OTC or PayMongo)', icon: '3' },
      { title: 'Waitlist Review', description: 'Owner/Staff verifies payment and waiver (30-day deadline)', icon: '4' },
      { title: 'Approval', description: 'Owner/Staff approves and reflects in accounts', icon: '5' },
      { title: 'Invite Email', description: 'Member receives and accepts invite', icon: '6' },
      { title: 'Account Setup', description: 'Member sets password and activates account', icon: '7' },
    ]
  },
  {
    title: 'Employee Invitation Lifecycle',
    id: 'employee-invitation',
    steps: [
      { title: 'Invite Creation', description: 'Owner navigates to invite logs and sends invite', icon: '1' },
      { title: 'Email Sent', description: 'Invite email sent with name, email, and role', icon: '2' },
      { title: 'Invite Acceptance', description: 'Staff/Coach clicks invite link', icon: '3' },
      { title: 'Password Setup', description: 'Employee sets password and configures account', icon: '4' },
      { title: 'Activation', description: 'Employee can now access role-specific modules', icon: '5' },
    ]
  },
  {
    title: 'Resubscription Lifecycle',
    id: 'resubscription',
    steps: [
      { title: 'Resubscribe Request', description: 'Member initiates resubscription in profile page', icon: '1' },
      { title: 'Validation', description: 'System validates annual (450 days) and total (365 days) caps', icon: '2' },
      { title: 'Payment Processing', description: 'Member completes payment transaction', icon: '3' },
      { title: 'Staff Verification', description: 'Owner/Staff verifies payment and approves', icon: '4' },
      { title: 'Audit Logging', description: 'Transaction logged in member and owner audit logs', icon: '5' },
      { title: 'Profile Update', description: 'Profile page reflects all active plans', icon: '6' },
    ]
  },
  {
    title: 'Account Deactivation',
    id: 'deactivation',
    steps: [
      { title: 'Deactivation Request', description: 'Owner initiates account deactivation', icon: '1' },
      { title: 'Reason Documentation', description: 'Owner states reason for deactivation', icon: '2' },
      { title: 'Status Update', description: 'Account status changes to deactivated', icon: '3' },
      { title: 'User Notification', description: 'Deactivation reason sent to member/employee', icon: '4' },
      { title: 'Access Revoked', description: 'User cannot log in anymore', icon: '5' },
    ]
  },
]

export default function LifecyclePage() {
  const [selectedWorkflow, setSelectedWorkflow] = useState('member-onboarding')
  const currentWorkflow = workflows.find(w => w.id === selectedWorkflow)

  return (
    <>
      <Navbar />
      
      <div className="min-h-screen bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          {/* Header */}
          <div className="text-center mb-16">
            <h1 className="text-4xl sm:text-5xl font-bold mb-4">Platform Lifecycles</h1>
            <p className="text-lg text-muted-foreground">Complete workflow documentation for all major system processes</p>
          </div>

          {/* Workflow Selector */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-12">
            {workflows.map((workflow) => (
              <button
                key={workflow.id}
                onClick={() => setSelectedWorkflow(workflow.id)}
                className={`p-6 rounded-lg border transition-all text-left ${
                  selectedWorkflow === workflow.id
                    ? 'border-accent bg-accent/10'
                    : 'border-border/50 hover:border-accent/30 hover:bg-card/50'
                }`}
              >
                <h3 className={`font-semibold ${selectedWorkflow === workflow.id ? 'text-accent' : 'text-foreground'}`}>
                  {workflow.title}
                </h3>
                <p className="text-sm text-muted-foreground mt-1">{workflow.steps.length} steps</p>
              </button>
            ))}
          </div>

          {/* Workflow Steps */}
          {currentWorkflow && (
            <div className="bg-card/30 border border-border/50 rounded-lg p-8">
              <h2 className="text-2xl font-bold mb-8">{currentWorkflow.title}</h2>
              
              <div className="space-y-6">
                {currentWorkflow.steps.map((step, index) => (
                  <div key={index} className="flex gap-6">
                    {/* Step Number */}
                    <div className="flex flex-col items-center">
                      <div className="w-10 h-10 rounded-full bg-accent/20 border-2 border-accent flex items-center justify-center font-semibold text-accent">
                        {step.icon}
                      </div>
                      {index < currentWorkflow.steps.length - 1 && (
                        <div className="w-1 h-16 bg-accent/30 my-2" />
                      )}
                    </div>

                    {/* Step Content */}
                    <div className="flex-1 pt-1">
                      <h3 className="text-lg font-semibold mb-2">{step.title}</h3>
                      <p className="text-muted-foreground">{step.description}</p>
                    </div>
                  </div>
                ))}
              </div>

              {/* Timeline Info */}
              <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-4 pt-8 border-t border-border/50">
                <div className="p-4 bg-background/50 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <Clock className="w-5 h-5 text-accent" />
                    <span className="font-semibold">Duration</span>
                  </div>
                  <p className="text-sm text-muted-foreground">Varies based on approvals and user actions</p>
                </div>
                <div className="p-4 bg-background/50 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <CheckCircle className="w-5 h-5 text-accent" />
                    <span className="font-semibold">Completion</span>
                  </div>
                  <p className="text-sm text-muted-foreground">Automatic once all steps are fulfilled</p>
                </div>
                <div className="p-4 bg-background/50 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <AlertCircle className="w-5 h-5 text-accent" />
                    <span className="font-semibold">Notifications</span>
                  </div>
                  <p className="text-sm text-muted-foreground">Sent at key milestones</p>
                </div>
              </div>
            </div>
          )}

          {/* Process Flow Diagram */}
          <div className="mt-16">
            <h3 className="text-2xl font-bold mb-8">Process Flow Diagram</h3>
            <div className="bg-card/30 border border-border/50 rounded-lg p-8 overflow-x-auto">
              <div className="flex items-center justify-between min-w-max">
                {currentWorkflow?.steps.map((step, index) => (
                  <div key={index} className="flex items-center">
                    <div className="text-center">
                      <div className="w-12 h-12 rounded-lg bg-accent/10 border-2 border-accent/50 flex items-center justify-center font-semibold text-accent mb-2 mx-auto">
                        {step.icon}
                      </div>
                      <p className="text-xs font-semibold text-muted-foreground max-w-[80px]">{step.title}</p>
                    </div>
                    {index < (currentWorkflow?.steps.length || 0) - 1 && (
                      <div className="w-12 flex justify-center">
                        <ArrowRight className="w-5 h-5 text-accent/50" />
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Key Actors & Roles */}
          <div className="mt-16 grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-card/30 border border-border/50 rounded-lg p-8">
              <h3 className="text-xl font-bold mb-4">Key Actors</h3>
              <div className="space-y-3">
                <div className="flex items-start gap-3">
                  <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-accent/20 text-accent font-semibold text-sm flex-shrink-0">M</span>
                  <div>
                    <p className="font-semibold">Member</p>
                    <p className="text-sm text-muted-foreground">Primary user taking actions in the system</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-accent/20 text-accent font-semibold text-sm flex-shrink-0">O</span>
                  <div>
                    <p className="font-semibold">Owner/Staff</p>
                    <p className="text-sm text-muted-foreground">Administrative user reviewing and approving actions</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-accent/20 text-accent font-semibold text-sm flex-shrink-0">S</span>
                  <div>
                    <p className="font-semibold">System</p>
                    <p className="text-sm text-muted-foreground">Automated processes and notifications</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-card/30 border border-border/50 rounded-lg p-8">
              <h3 className="text-xl font-bold mb-4">Important Notes</h3>
              <ul className="space-y-3 text-sm text-muted-foreground">
                <li className="flex gap-2">
                  <span className="text-accent">•</span>
                  <span>All workflows are logged in audit trails for compliance</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-accent">•</span>
                  <span>Deadlines and caps are enforced by the system automatically</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-accent">•</span>
                  <span>Notifications are sent at each critical step</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-accent">•</span>
                  <span>All user actions are tracked and reported</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}
