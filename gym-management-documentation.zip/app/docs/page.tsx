'use client'

import { Navbar } from '@/components/navbar'
import { Button } from '@/components/ui/button'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { ChevronRight, Lock, Users, QrCode, Calendar, BarChart3, Bell, CreditCard, Zap, Database } from 'lucide-react'
import Link from 'next/link'
import { useState } from 'react'

const docCategories = [
  {
    title: 'Authentication & RBAC',
    icon: Lock,
    id: 'auth-rbac',
    subsections: ['Overview', 'User Roles', 'Permission Matrix', 'Implementation'],
  },
  {
    title: 'Member Management',
    icon: Users,
    id: 'member-management',
    subsections: ['Registration Flow', 'Profile Management', 'Plans & Subscriptions', 'Member Lifecycle'],
  },
  {
    title: 'Coach & Staff',
    icon: Zap,
    id: 'coach-management',
    subsections: ['Staff Management', 'Role Assignment', 'Availability', 'Scheduling'],
  },
  {
    title: 'QR Check-In',
    icon: QrCode,
    id: 'qr-checkin',
    subsections: ['QR System', 'Check-In Process', 'Attendance Tracking', 'Reports'],
  },
  {
    title: 'Booking & Scheduling',
    icon: Calendar,
    id: 'scheduling',
    subsections: ['Class Scheduling', 'Booking System', 'Trainer Availability', 'Calendar Integration'],
  },
  {
    title: 'Payment System',
    icon: CreditCard,
    id: 'payments',
    subsections: ['PayMongo Integration', 'Payment Methods', 'Subscription Billing', 'Transaction Logs'],
  },
  {
    title: 'Analytics Module',
    icon: BarChart3,
    id: 'analytics',
    subsections: ['Machine Learning', 'Predictive Models', 'Data Analysis', 'Insights'],
  },
  {
    title: 'Reports',
    icon: Database,
    id: 'reports',
    subsections: ['Report Generation', 'Export Options', 'Scheduled Reports', 'Custom Reports'],
  },
  {
    title: 'Notifications',
    icon: Bell,
    id: 'notifications',
    subsections: ['SMS Notifications', 'Email Alerts', 'In-App Messages', 'Notification Settings'],
  },
  {
    title: 'API & Architecture',
    icon: Database,
    id: 'api-architecture',
    subsections: ['API Overview', 'Endpoints', 'Authentication', 'Rate Limiting'],
  },
]

export default function DocsPage() {
  const [selectedCategory, setSelectedCategory] = useState('auth-rbac')
  const currentCategory = docCategories.find(c => c.id === selectedCategory)

  return (
    <>
      <Navbar />
      
      <div className="flex min-h-screen">
        {/* Sidebar */}
        <aside className="hidden lg:flex w-64 border-r border-border/50 bg-card/30 flex-col">
          <div className="p-6 space-y-4">
            <div className="space-y-2">
              <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Documentation</h3>
              <input 
                type="text" 
                placeholder="Search docs..." 
                className="w-full px-3 py-2 text-sm rounded-lg bg-background border border-border/50 text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent/50"
              />
            </div>

            <nav className="space-y-1">
              {docCategories.map((category) => {
                const Icon = category.icon
                return (
                  <button
                    key={category.id}
                    onClick={() => setSelectedCategory(category.id)}
                    className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-lg transition-colors text-sm ${
                      selectedCategory === category.id
                        ? 'bg-accent/20 text-accent font-semibold'
                        : 'text-muted-foreground hover:text-foreground hover:bg-card/50'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    {category.title}
                  </button>
                )
              })}
            </nav>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 overflow-auto">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
            {currentCategory && (
              <div className="space-y-8">
                {/* Header */}
                <div className="space-y-4">
                  <div className="flex items-start gap-4">
                    {(() => {
                      const Icon = currentCategory.icon
                      return <Icon className="w-8 h-8 text-accent mt-1" />
                    })()}
                    <div>
                      <h1 className="text-4xl font-bold">{currentCategory.title}</h1>
                      <p className="text-muted-foreground mt-2">Complete documentation and implementation guide for {currentCategory.title.toLowerCase()}</p>
                    </div>
                  </div>
                </div>

                {/* Subsections Navigation */}
                <div className="flex gap-2 flex-wrap">
                  {currentCategory.subsections.map((subsection) => (
                    <button
                      key={subsection}
                      className="px-4 py-2 rounded-lg border border-border/50 hover:border-accent/50 hover:bg-card/50 transition-all text-sm"
                    >
                      {subsection}
                    </button>
                  ))}
                </div>

                {/* Content Tabs */}
                <Tabs defaultValue="overview" className="space-y-6">
                  <TabsList className="grid w-full grid-cols-4 bg-card/50 border border-border/50">
                    <TabsTrigger value="overview">Overview</TabsTrigger>
                    <TabsTrigger value="implementation">Implementation</TabsTrigger>
                    <TabsTrigger value="examples">Examples</TabsTrigger>
                    <TabsTrigger value="api">API</TabsTrigger>
                  </TabsList>

                  <TabsContent value="overview" className="space-y-4">
                    <div className="prose prose-invert max-w-none space-y-4">
                      <div className="p-6 border border-border/50 rounded-lg bg-card/30">
                        <h3 className="text-lg font-semibold mb-3">Overview</h3>
                        <p className="text-muted-foreground leading-relaxed">
                          This section contains comprehensive documentation for {currentCategory.title.toLowerCase()}. 
                          Learn about the key concepts, workflows, and best practices for implementing this feature in your gym management system.
                        </p>
                      </div>

                      <div className="space-y-4">
                        <h3 className="text-lg font-semibold">Key Features</h3>
                        <ul className="space-y-2">
                          {currentCategory.subsections.map((subsection) => (
                            <li key={subsection} className="flex items-center gap-3 text-muted-foreground">
                              <ChevronRight className="w-4 h-4 text-accent flex-shrink-0" />
                              {subsection}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </TabsContent>

                  <TabsContent value="implementation" className="space-y-4">
                    <div className="p-6 border border-border/50 rounded-lg bg-card/30">
                      <h3 className="text-lg font-semibold mb-4">Implementation Guide</h3>
                      <div className="space-y-4 text-muted-foreground">
                        <p>Step-by-step implementation guide for {currentCategory.title.toLowerCase()}:</p>
                        <ol className="space-y-3 ml-6 list-decimal">
                          <li>Understand the core concepts and workflows</li>
                          <li>Set up the necessary database models and schemas</li>
                          <li>Configure authentication and authorization rules</li>
                          <li>Implement the business logic and API endpoints</li>
                          <li>Add frontend components and user interfaces</li>
                          <li>Test thoroughly with the provided test cases</li>
                        </ol>
                      </div>
                    </div>
                  </TabsContent>

                  <TabsContent value="examples" className="space-y-4">
                    <div className="p-6 border border-border/50 rounded-lg bg-card/30">
                      <h3 className="text-lg font-semibold mb-4">Code Examples</h3>
                      <div className="bg-background/50 p-4 rounded-lg border border-border/50 font-mono text-sm overflow-auto">
                        <pre className="text-muted-foreground">{`// Example implementation for ${currentCategory.title.toLowerCase()}
// Refer to the full documentation for complete examples

const implementation = async () => {
  // Initialize the module
  // Configure settings
  // Set up handlers
  // Connect to services
}

// For full examples, see the GitHub repository`}</pre>
                      </div>
                    </div>
                  </TabsContent>

                  <TabsContent value="api" className="space-y-4">
                    <div className="p-6 border border-border/50 rounded-lg bg-card/30">
                      <h3 className="text-lg font-semibold mb-4">API Reference</h3>
                      <div className="space-y-4 text-muted-foreground text-sm">
                        <p>API endpoints for {currentCategory.title.toLowerCase()}:</p>
                        <div className="space-y-2 font-mono">
                          <div className="p-3 bg-background/50 rounded border border-border/50">
                            <span className="text-green-400">GET</span> /api/{currentCategory.id}
                          </div>
                          <div className="p-3 bg-background/50 rounded border border-border/50">
                            <span className="text-blue-400">POST</span> /api/{currentCategory.id}
                          </div>
                          <div className="p-3 bg-background/50 rounded border border-border/50">
                            <span className="text-yellow-400">PUT</span> /api/{currentCategory.id}/{'{id}'}
                          </div>
                          <div className="p-3 bg-background/50 rounded border border-border/50">
                            <span className="text-red-400">DELETE</span> /api/{currentCategory.id}/{'{id}'}
                          </div>
                        </div>
                      </div>
                    </div>
                  </TabsContent>
                </Tabs>

                {/* Navigation */}
                <div className="flex justify-between pt-8 border-t border-border/50">
                  <Button variant="outline" className="border-border/50">
                    ← Previous
                  </Button>
                  <Button className="bg-accent hover:bg-accent/90">
                    Next →
                  </Button>
                </div>
              </div>
            )}
          </div>
        </main>
      </div>
    </>
  )
}
