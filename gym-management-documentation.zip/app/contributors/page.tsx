'use client'

import { Navbar } from '@/components/navbar'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Github, Linkedin, Twitter, Mail } from 'lucide-react'
import Link from 'next/link'

const contributors = [
  {
    name: 'Adrian Aldave',
    socials: [
      { icon: Github, href: '#', label: 'GitHub' },
      { icon: Linkedin, href: '#', label: 'LinkedIn' },
      { icon: Mail, href: '#', label: 'Email' },
    ],
  },
  {
    name: 'Karmelo Andrei Cortes',
    socials: [
      { icon: Github, href: '#', label: 'GitHub' },
      { icon: Linkedin, href: '#', label: 'LinkedIn' },
      { icon: Mail, href: '#', label: 'Email' },
    ],
  },
  {
    name: 'Phol Mari Garcia',
    socials: [
      { icon: Github, href: '#', label: 'GitHub' },
      { icon: Linkedin, href: '#', label: 'LinkedIn' },
      { icon: Mail, href: '#', label: 'Email' },
    ],
  },
  {
    name: 'Dawn Carla Germones',
    socials: [
      { icon: Github, href: '#', label: 'GitHub' },
      { icon: Linkedin, href: '#', label: 'LinkedIn' },
      { icon: Mail, href: '#', label: 'Email' },
    ],
  },
]

export default function ContributorsPage() {
  return (
    <>
      <Navbar />
      
      <div className="min-h-screen bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          {/* Header */}
          <div className="text-center mb-16">
            <h1 className="text-4xl sm:text-5xl font-bold mb-4">Our Team</h1>
            <p className="text-lg text-muted-foreground">The team behind GNEX 360</p>
          </div>

          {/* Contributors Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {contributors.map((contributor) => (
              <div
                key={contributor.name}
                className="group border border-border/50 rounded-lg overflow-hidden hover:border-accent/50 hover:bg-card/50 transition-all"
              >
                {/* Header Background */}
                <div className="h-24 bg-gradient-to-r from-accent/20 to-accent/5" />

                {/* Content */}
                <div className="px-6 pb-6">
                  {/* Avatar */}
                  <div className="flex justify-center -mt-12 mb-4">
                    <Avatar className="w-24 h-24 border-4 border-background">
                      <AvatarFallback className="bg-accent text-accent-foreground text-lg font-bold">
                        {contributor.name
                          .split(' ')
                          .map((n) => n[0])
                          .join('')}
                      </AvatarFallback>
                    </Avatar>
                  </div>

                  {/* Info */}
                  <div className="text-center mb-6">
                    <h3 className="text-lg font-bold">{contributor.name}</h3>
                  </div>

                  {/* Social Links */}
                  <div className="flex justify-center gap-3">
                    {contributor.socials.map((social) => {
                      const Icon = social.icon
                      return (
                        <Link
                          key={social.label}
                          href={social.href}
                          className="p-2 rounded-lg hover:bg-card/50 border border-border/50 hover:border-accent/50 transition-all"
                          aria-label={social.label}
                        >
                          <Icon className="w-4 h-4 text-muted-foreground hover:text-accent transition-colors" />
                        </Link>
                      )
                    })}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  )
}
