import { Navbar } from '@/components/navbar'
import { Button } from '@/components/ui/button'
import { Users, Zap, QrCode, Calendar, BarChart3, Bell, CreditCard, Lock, ArrowRight } from 'lucide-react'
import Link from 'next/link'

export default function Page() {
  return (
    <>
      <Navbar />
      
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20">
        {/* Background gradient */}
        <div className="absolute inset-0 -z-10">
          <div className="absolute top-0 left-1/4 w-96 h-96 bg-accent/20 rounded-full blur-3xl opacity-20 animate-pulse" />
          <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-accent/10 rounded-full blur-3xl opacity-10 animate-pulse" />
        </div>

        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="space-y-6">
            <div className="inline-block">
              <span className="text-sm font-semibold px-4 py-1.5 bg-accent/10 border border-accent/30 rounded-full text-accent">
                Documentation
              </span>
            </div>

            <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold tracking-tight">
              GNEX 360<br />
              <span className="text-accent">Documentation Center</span>
            </h1>

            <p className="text-lg sm:text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
              Complete platform documentation for gym member management, AI-powered analytics, QR attendance tracking, scheduling, payments, and comprehensive reporting systems.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center pt-8">
              <Link href="/docs">
                <Button size="lg" className="w-full sm:w-auto bg-accent hover:bg-accent/90 text-accent-foreground">
                  Explore Documentation
                  <ArrowRight className="ml-2 w-4 h-4" />
                </Button>
              </Link>
              <Link href="#features">
                <Button size="lg" variant="outline" className="w-full sm:w-auto border-border/50 hover:bg-card">
                  View Features
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Platform Capabilities */}
      <section id="features" className="py-20 border-t border-border/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">Platform Capabilities</h2>
            <p className="text-lg text-muted-foreground">Everything you need to manage the full gym lifecycle</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Member Management */}
            <Link href="/docs#member-management">
              <div className="group p-6 border border-border/50 rounded-lg hover:border-accent/50 hover:bg-card/50 transition-all cursor-pointer">
                <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center mb-4 group-hover:bg-accent/20 transition-colors">
                  <Users className="w-6 h-6 text-accent" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Member Management</h3>
                <p className="text-sm text-muted-foreground">Create and manage member profiles, plans, and hierarchy with role-based access control.</p>
              </div>
            </Link>

            {/* Coach Management */}
            <Link href="/docs#coach-management">
              <div className="group p-6 border border-border/50 rounded-lg hover:border-accent/50 hover:bg-card/50 transition-all cursor-pointer">
                <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center mb-4 group-hover:bg-accent/20 transition-colors">
                  <Zap className="w-6 h-6 text-accent" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Coach Management</h3>
                <p className="text-sm text-muted-foreground">Manage staff and coaching personnel with specialized roles and capabilities.</p>
              </div>
            </Link>

            {/* QR Check-In */}
            <Link href="/docs#qr-checkin">
              <div className="group p-6 border border-border/50 rounded-lg hover:border-accent/50 hover:bg-card/50 transition-all cursor-pointer">
                <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center mb-4 group-hover:bg-accent/20 transition-colors">
                  <QrCode className="w-6 h-6 text-accent" />
                </div>
                <h3 className="text-lg font-semibold mb-2">QR Check-In</h3>
                <p className="text-sm text-muted-foreground">Fast and efficient attendance tracking using QR code technology.</p>
              </div>
            </Link>

            {/* Scheduling & Booking */}
            <Link href="/docs#scheduling">
              <div className="group p-6 border border-border/50 rounded-lg hover:border-accent/50 hover:bg-card/50 transition-all cursor-pointer">
                <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center mb-4 group-hover:bg-accent/20 transition-colors">
                  <Calendar className="w-6 h-6 text-accent" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Scheduling</h3>
                <p className="text-sm text-muted-foreground">Manage class schedules, bookings, and trainer availability.</p>
              </div>
            </Link>

            {/* Analytics & Reports */}
            <Link href="/docs#analytics">
              <div className="group p-6 border border-border/50 rounded-lg hover:border-accent/50 hover:bg-card/50 transition-all cursor-pointer">
                <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center mb-4 group-hover:bg-accent/20 transition-colors">
                  <BarChart3 className="w-6 h-6 text-accent" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Analytics & Reports</h3>
                <p className="text-sm text-muted-foreground">Predictive analytics using machine learning with detailed reporting capabilities.</p>
              </div>
            </Link>

            {/* Notifications */}
            <Link href="/docs#notifications">
              <div className="group p-6 border border-border/50 rounded-lg hover:border-accent/50 hover:bg-card/50 transition-all cursor-pointer">
                <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center mb-4 group-hover:bg-accent/20 transition-colors">
                  <Bell className="w-6 h-6 text-accent" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Notifications</h3>
                <p className="text-sm text-muted-foreground">Real-time notifications and communication system for members and staff.</p>
              </div>
            </Link>

            {/* Payments */}
            <Link href="/docs#payments">
              <div className="group p-6 border border-border/50 rounded-lg hover:border-accent/50 hover:bg-card/50 transition-all cursor-pointer">
                <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center mb-4 group-hover:bg-accent/20 transition-colors">
                  <CreditCard className="w-6 h-6 text-accent" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Payment Processing</h3>
                <p className="text-sm text-muted-foreground">Secure payment processing integrated with PayMongo.</p>
              </div>
            </Link>

            {/* RBAC */}
            <Link href="/hierarchy">
              <div className="group p-6 border border-border/50 rounded-lg hover:border-accent/50 hover:bg-card/50 transition-all cursor-pointer">
                <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center mb-4 group-hover:bg-accent/20 transition-colors">
                  <Lock className="w-6 h-6 text-accent" />
                </div>
                <h3 className="text-lg font-semibold mb-2">RBAC & Security</h3>
                <p className="text-sm text-muted-foreground">Role-based access control with granular permission management.</p>
              </div>
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border/50 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h4 className="font-semibold mb-4">Documentation</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><Link href="/docs" className="hover:text-foreground transition-colors">DevDocs</Link></li>
                <li><Link href="/lifecycle" className="hover:text-foreground transition-colors">Lifecycle</Link></li>
                <li><Link href="/qa" className="hover:text-foreground transition-colors">QA Testing</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Platform</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><Link href="/hierarchy" className="hover:text-foreground transition-colors">Hierarchy</Link></li>
                <li><Link href="/architecture" className="hover:text-foreground transition-colors">Architecture</Link></li>
                <li><Link href="/contributors" className="hover:text-foreground transition-colors">Contributors</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Features</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>Member Management</li>
                <li>Analytics</li>
                <li>QR Check-In</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">About</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>GNEX 360</li>
                <li>Capstone Project</li>
                <li>2025-2026</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-border/50 pt-8 text-center text-sm text-muted-foreground">
            <p>&copy; 2026 GNEX 360. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </>
  )
}
