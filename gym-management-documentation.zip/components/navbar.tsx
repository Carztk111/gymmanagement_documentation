'use client'

import Link from 'next/link'
import { Search } from 'lucide-react'
import { Input } from '@/components/ui/input'

export function Navbar() {
  return (
    <nav className="sticky top-0 z-50 border-b border-border/50 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 font-bold text-xl hover:opacity-80 transition-opacity">
            <div className="w-8 h-8 bg-accent rounded flex items-center justify-center">
              <span className="text-accent-foreground font-bold text-sm">G</span>
            </div>
            <span>GNEX 360</span>
          </Link>

          {/* Navigation Links */}
          <div className="hidden md:flex items-center gap-8">
            <Link href="#features" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              Features
            </Link>
            <Link href="/docs" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              DevDocs
            </Link>
            <Link href="/lifecycle" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              Lifecycle
            </Link>
            <Link href="/qa" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              QA Testing
            </Link>
            <Link href="/architecture" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              Architecture
            </Link>
            <Link href="/hierarchy" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              Hierarchy
            </Link>
            <Link href="/contributors" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              Contributors
            </Link>
          </div>

          {/* Search */}
          <div className="hidden md:flex items-center gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input 
                placeholder="Search docs..." 
                className="pl-9 w-48 bg-card border-border/50 text-sm"
              />
            </div>
          </div>
        </div>
      </div>
    </nav>
  )
}
